1. Let’s Create a basic React component that renders a simple “Hello, World!” message.
   Steps:

   - Set up a new React project using "npm create vite@latest" or a similar tool.
   - Create a new file named HelloWorld.jsx in the src directory.
   - Define a component named HelloWorld.
   - Inside the HelloWorld component, return a JSX element that displays the “Hello, World!” message.
