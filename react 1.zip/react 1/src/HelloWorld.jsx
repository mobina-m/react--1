import React from "react";
function HelloWorld() {
  return <h1 style={{ color: "blue" }}>Hello, World!</h1>;
}
export default HelloWorld;
